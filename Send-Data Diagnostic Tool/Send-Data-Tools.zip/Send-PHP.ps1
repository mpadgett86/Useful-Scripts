<#
    This function can be placed within any PowerShell script and invoked to
    send data back for analysis.

    ** The purpose of this process is to retrieve data such as return codes from a script run.

    ** The reason this is needed is because Intune only tells an Admin
        whether or not a script failed. Unless the Admin has remote or direct
        physical access to the machine, it becomes very difficult to diagnose bugs
        in PowerShell scripts.

#>

function Send-Data ($DataToSend){

    # $name is to be used as the file name for the data.
    $name = $env:computername                       

    # $date is for log analysis
    $date = Get-Date -format "dd-MMM-yyyy HH:mm"
    
    # $postParams encapsulates data to be send to the server
    $postParams = @{name = $name } + @{date = $date } + @{data = $DataToSend }
    
    # Data is sent to IP:PORT
    Invoke-WebRequest -Uri 127.0.0.1:2222/server.php -Method POST -Body $postParams

}

Send-Data "This is some *NEW* test data that represents another Return = 0 Success Code."